package com.ezen.biz.dto;

import lombok.Data;
//테이블의 일부 카테고리 작업을 위해서 만든 클래스 Mybatis ResultType과 연동

@Data
public class ScateInfo {
	private String ptype1,ptype2;
}
