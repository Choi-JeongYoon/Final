package com.ezen.biz.dto;

import lombok.Data;
@Data
public class CateVO {

private String ptype1,ptype2,ptype3,ptype4,ptype5,ptype6,ptype7;
}
