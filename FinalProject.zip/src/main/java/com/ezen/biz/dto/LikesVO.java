package com.ezen.biz.dto;

import lombok.Data;

@Data
public class LikesVO {
	private int lnum,pnum,price;
	private String id;
}
