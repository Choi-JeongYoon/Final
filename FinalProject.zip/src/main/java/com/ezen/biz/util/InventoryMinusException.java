package com.ezen.biz.util;

public class InventoryMinusException extends Exception {

	public InventoryMinusException() {
		super();
	}

	public InventoryMinusException(String message) {
		super(message);
	}
	
}
